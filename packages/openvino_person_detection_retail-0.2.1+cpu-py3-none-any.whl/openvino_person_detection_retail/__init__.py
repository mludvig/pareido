__version__ = "0.2.1"
from openvino_person_detection_retail.model import InferenceModel
